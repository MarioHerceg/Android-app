package hr.tvz.android.fragmentiherceg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.raizlabs.android.dbflow.sql.language.SQLite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends FragmentActivity
        implements ItemListFragment.Callbacks {

    public static final String MOJ_KANAL = "mojaAplikacija";
    public static List<Show> listaFilmova;
    public static Map<String, Show> ITEM_MAP = new HashMap<>();

    private boolean mTwoPane;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list2);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(MOJ_KANAL, "Ime kanala", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Opis kanala");
            NotificationManager man = (NotificationManager)(getSystemService(Context.NOTIFICATION_SERVICE));
            man.createNotificationChannel(channel);
        }

        // Dohvat registracijskog tokena uređaja za Firebase
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("Main activity", "getInstanceId failed", task.getException());
                            return;
                        }
                        // Get new Instance ID token
                        String token = task.getResult().getToken();

                        Log.d("Main activity", token);
                        Toast.makeText(MainActivity.this, token, Toast.LENGTH_SHORT).show();
                    }
                });
        makeMovies();
        listaFilmova = getMovies();

        for(Show item : listaFilmova){
            ITEM_MAP.put(item.getId(), item);
        }

        if(findViewById(R.id.item_detail_container) != null) {
            mTwoPane = true;

            ((ItemListFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.item_list))
                    .setActivateOnItemClick(true);
        } else {
            mTwoPane = false;
            ItemListFragment listFragment = new ItemListFragment();
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.item_list_container, listFragment)
                    .commit();
        }

    }

    private List<Show> getMovies() {
        List<Show> shows = SQLite.select().from(Show.class).queryList();
        return shows;
    }

    private void makeMovies() {
        List<Show> shows = new ArrayList<Show>();
        shows.add(new Show("1","Game of Thrones", "2011-2019", "David Benioff", "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia.","9.2",R.drawable.game_of_thrones,"https://www.imdb.com/title/tt0944947/"));
        shows.add(new Show("2","Breaking Bad", "2008-2013", "Vince Gilligan", "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.","9.4",R.drawable.breaking_bad,"https://www.imdb.com/title/tt0903747/"));
        shows.add(new Show("3","Sherlock", "2010-", "Mark Gatiss", "A modern update finds the famous sleuth and his doctor partner solving crime in 21st century London.","9.1",R.drawable.sherlock,"https://www.imdb.com/title/tt1475582/"));
        shows.add(new Show("4","Friends ", "1994-2004", "David Crane", "Follows the personal and professional lives of six twenty to thirty-something-year-old friends living in Manhattan.","8.8",R.drawable.friends,"https://www.imdb.com/title/tt0108778/"));
        shows.add(new Show("5","Stranger Things ", "2016-", "Matt Duffer", "When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces in order to get him back.","8.7",R.drawable.stranger_things,"https://www.imdb.com/title/tt4574334/"));
        shows.add(new Show("6","Dexter", "2006-2013", "James Manos Jr.", "By day, mild-mannered Dexter is a blood-spatter analyst for the Miami police. But at night, he is a serial killer who only targets other murderers.","8.6",R.drawable.dexter,"https://www.imdb.com/title/tt0773262/"));
        shows.add(new Show("7","True Detective ", "2014-", "Nic Pizzolatto", "Seasonal anthology series in which police investigations unearth the personal and professional secrets of those involved, both within and outside the law.","8.9",R.drawable.true_detective,"https://www.imdb.com/title/tt2356777/"));

        for(Show sejv : shows){
            sejv.save();
        }
    }

    @Override
    public void onItemSelected(String id) {
        Bundle arguments = new Bundle();
        arguments.putString(ItemDetailFragment.ARG_ITEM_ID, id);
        ItemDetailFragment detailFragment = new ItemDetailFragment();
        detailFragment.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager()
                .beginTransaction();

        if(mTwoPane) {
            fragmentTransaction
                    .replace(R.id.item_detail_container, detailFragment)
                    .commit();
        } else {
            fragmentTransaction
                    .addToBackStack(null)
                    .replace(R.id.item_list_container, detailFragment)
                    .commit();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_share:
                DialogFragment dialogFragment = new EuroDialogFragment();
                dialogFragment.show(getSupportFragmentManager(), "EuroDialog");
            default:
                break;
        }
        return true;
    }
}
