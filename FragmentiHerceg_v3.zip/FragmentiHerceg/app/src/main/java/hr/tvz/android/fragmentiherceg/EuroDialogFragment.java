package hr.tvz.android.fragmentiherceg;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class EuroDialogFragment extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Izrada dialoga
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.dialog_message)
                .setPositiveButton(R.string.da, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String uniqueActionString = "hr.android.broadcast.testbc";
                        Intent broadcastIntent = new Intent(uniqueActionString);
                        getActivity().sendBroadcast(broadcastIntent);
                    }
                })
                .setNegativeButton(R.string.ne, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast t = Toast.makeText(getActivity(), "A dobro ak' neces.", Toast.LENGTH_LONG);
                        t.setGravity(Gravity.BOTTOM, 0, 0);
                        t.show();
                    }
                });
        return builder.create();
    }
}
