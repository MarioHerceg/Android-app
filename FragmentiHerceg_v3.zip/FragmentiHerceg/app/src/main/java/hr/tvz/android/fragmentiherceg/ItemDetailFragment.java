package hr.tvz.android.fragmentiherceg;

import android.app.FragmentManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class ItemDetailFragment extends Fragment {
    /**
     * The fragment argument representing the item ID that this fragment
     * represents.
     */
    public static final String ARG_ITEM_ID = "item_id";

    /**
     * The dummy content this fragment is presenting.
     */
    private Show mItem;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ItemDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey(ARG_ITEM_ID)) {
            // Load the dummy content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            mItem = MainActivity.ITEM_MAP.get(getArguments().getString(ARG_ITEM_ID));
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_movie_details, container, false);

        // Show the dummy content as text in a TextView.
        if (mItem != null) {
            ((TextView) rootView.findViewById(R.id.naslov)).setText(mItem.getName());
            ((TextView) rootView.findViewById(R.id.godina)).setText(mItem.getYear());
            ((TextView) rootView.findViewById(R.id.direktor)).setText("Creator: "+mItem.getDirector());
            ((TextView) rootView.findViewById(R.id.opis)).setText(mItem.getStoryLine());
            ((TextView) rootView.findViewById(R.id.trivia)).setText("IMDB ocjena: "+mItem.getImdb_ocjena());

            ImageView img = (ImageView) rootView.findViewById(R.id.imageView);
            img.setImageResource(mItem.getSlika());
            img.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v){
                    Intent intent = new Intent(getContext(), SlikaDetailsActivity.class);
                    intent.putExtra("slika", mItem);
                    startActivity(intent);
                }
            });

            Button btn = rootView.findViewById(R.id.button);
            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Animation animation = AnimationUtils.loadAnimation(getContext(),R.anim.animacija2);
                    v.startAnimation(animation);
                    String url = mItem.getUrl();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });
        }

        return rootView;
    }

    public Show getmItem() {
        return mItem;
    }
}
