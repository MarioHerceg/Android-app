package hr.tvz.android.fragmentiherceg;

import android.os.Parcel;
import android.os.Parcelable;

import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.ArrayList;
import java.util.List;

@Table(database = BazaPodataka.class)
public class Show extends BaseModel implements Parcelable{

    @Column
    @PrimaryKey
    private String id;

    @Column
    private String name;

    @Column
    private String year;

    @Column
    private String director;

    @Column
    private String storyLine;

    @Column
    private String imdb_ocjena;

    @Column
    private Integer slika;

    @Column
    private String url;


    public Show() {
    }

    public Show(String id, String name, String year, String director, String storyLine,
                String imdb_ocjena, Integer slika, String url) {
        this.id=id;
        this.name = name;
        this.year = year;
        this.director = director;
        this.storyLine = storyLine;
        this.imdb_ocjena = imdb_ocjena;
        this.slika = slika;
        this.url = url;
    }

    public Show(Parcel source) {
        List<String> lista = new ArrayList<String>();
        source.readStringList(lista);
        if (lista != null && lista.size() == 8) {
            this.id=lista.get(0);
            this.name = lista.get(1);
            this.year = lista.get(2);
            this.director = lista.get(3);
            this.storyLine = lista.get(4);
            this.imdb_ocjena = lista.get(5);
            this.slika=Integer.parseInt(lista.get(6));
            this.url=lista.get(7);
        }
    }

    @Override
    public int describeContents() {
        return name.hashCode() + year.hashCode() + director.hashCode();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        List<String> lista = new ArrayList<String>();
        lista.add(id);
        lista.add(name);
        lista.add(year);
        lista.add(director);
        lista.add(storyLine);
        lista.add(imdb_ocjena);
        lista.add(Integer.toString(slika));
        lista.add(url);
        dest.writeStringList(lista);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getStoryLine() {
        return storyLine;
    }

    public void setStoryLine(String storyLine) {
        this.storyLine = storyLine;
    }

    public String getImdb_ocjena() {
        return imdb_ocjena;
    }

    public void setImdb_ocjena(String imdb_ocjena) {
        this.imdb_ocjena = imdb_ocjena;
    }

    public Integer getSlika() {
        return slika;
    }

    public void setSlika(Integer slika) {
        this.slika = slika;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getId() { return id; }

    public void setId(String id) { this.id = id; }

    public static final Parcelable.Creator<Show> CREATOR = new Parcelable.Creator<Show>() {
        @Override
        public Show createFromParcel(Parcel source) {
            return new Show(source);
        }

        @Override
        public Show[] newArray(int size) {
            return new Show[size];
        }

    };

    @Override
    public String toString() {
        return name;
    }
}
