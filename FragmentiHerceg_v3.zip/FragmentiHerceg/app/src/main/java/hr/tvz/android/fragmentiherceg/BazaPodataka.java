package hr.tvz.android.fragmentiherceg;

import com.raizlabs.android.dbflow.annotation.Database;

@Database(name = BazaPodataka.NAME, version = BazaPodataka.VERSION)
public class BazaPodataka {
    public static final String NAME = "MojaBaza";

    public static final int VERSION = 1;
}
