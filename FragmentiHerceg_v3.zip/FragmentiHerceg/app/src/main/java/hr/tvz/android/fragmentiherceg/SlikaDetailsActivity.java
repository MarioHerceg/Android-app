package hr.tvz.android.fragmentiherceg;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class SlikaDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slika_details);

        Show slika = getIntent().getExtras().getParcelable("slika");

        ImageView img = (ImageView) findViewById(R.id.imageView2);
        img.setImageResource(slika.getSlika());

    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("Proba", "Vrijednost koju sam pohranio");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        String str = savedInstanceState.getString("Proba");
        Toast.makeText(this, "U varijabli je: " + str, Toast.LENGTH_SHORT).show();
    }

}
